<section class="container-fluid g-mt-100">
	<div class="row">
		<div class="col-md-6">
			<div class="u-shadow-v1-5 g-mb-30"> <img class="img-fluid w-100" src="<?php echo base_url();?>assets/img/service/1.jpg" alt="Image Description" style="height: 330px;"> </div> 
		</div>
		<div class="col-md-6">
			<div class="u-shadow-v1-5 g-line-height-2 g-pa-40 g-mb-30" role="alert">
		      <h3 class="h2 g-font-weight-300 g-mb-20 text-center">Jasa Pemasangan Paving Block</h3>
		      <p class="mb-0 text-justify">
		        Sinar Baru Conblock menyediakan jasa pemasangan paving block untuk Area Parkir, Jalan Lingkungan, Jalan Perumahan, Taman, Area Pabrik dan lain-lain. Dengan SDM yang ahli dibidangnya kami dapat melakukan dari proses pengerjaan hingga finishingnya dengan biaya yang terjangkau. Area pekerjaan peving block meliputi area .........................................
		        Untuk info harga lebih lanjut silahkan <a href="<?php echo base_url()?>Home/kontak">hubungi kami</a>
		      </p>
		    </div>
		</div>
	</div>
	
	
</section>