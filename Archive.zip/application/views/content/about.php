<div class="container">

	<section class="g-mt-70">
		<h1 class="text-center">Sekilas Mengenal Sinar Baru Conblock</h1>
		<div class="text-center">
			<img class="img-fluid" src="<?php echo base_url()?>assets/img/content/logo-SB-high.png">
		</div>
		
		<p class="text-center g-font-size-20">
			Sinar Baru Conblock berdiri sejak ............ seiring berjalannya waktu semakin banyak aneka Precast yang kami buat dan kami menjadi Distributor untuk penjualan beton precast. Dan karena banyaknya permintaan, kami juga sudah menyiapkan jasa pemasangan Paving Block dengan SDM yang berpengalaman dibidangnya.
			Semua produk kami sangat menjamin akan mutu kualitas. Kami siap memenuhi kebutuhan precast untuk project Pemerintahan dan Swasta untuk wilayah .............
			Kami Sinar Baru Conblock akan memberikan pelayanan dan kualitas terbaik 

		</p>
	</section>
	<section class="g-mt-30 g-mb-100">
		<h2 class="text-center">Lokasi</h2>
		<p class="g-font-size-18">
		Lokasi kantor kami terletak di dua tempat yaitu Jl.Raya Jatimulya No.1 Ttugu Perbatasan) Cilodong Depok dan Jl. Ksr Dadi Kusmayadi (samping Kelurahan Desa Tengah) Cipayung, Cibinong – Bogor. Dan untuk lokasi Workshop berada di Jl. Setu Bek-ang (belakang Rusun Bek-ang) Cibinong – Bogor.<br> Produk-produk Precast yang kami produksi antara lain:
		</p>
		<ul class="g-font-size-16">
			<li>Paving Block</li>
			<li>Buis Beton</li>
			<li>Genteng Beton</li>
			<li>Grass Blok</li>
			<li>Loster Beton</li>
			<li>U-Dicth</li>
			<li>Dll</li>

		</ul>
	</section>
</div>